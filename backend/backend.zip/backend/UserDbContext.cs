﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using backend.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;

namespace backend
{
    public class UserDbContext : IdentityDbContext<IdentityUser>
    {
        public UserDbContext(DbContextOptions<UserDbContext> options) : base(options) { }
        //public DbSet<Models.Question> Questions { get; set; } //Columns
        //public DbSet<backend.Models.Quiz> Quiz { get; set; }

    }
}

//When you retrieve data using ORM it's always in generic.